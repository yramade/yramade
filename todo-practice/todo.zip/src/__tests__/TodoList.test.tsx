import { render, screen, fireEvent } from '@testing-library/react';
import TodoList from '../components/TodoList';
import { describe, it, expect, vi } from 'vitest';

describe('TodoList', () => {
  const todos = [
    { id: '1', text: '할 일 1', completed: false },
    { id: '2', text: '할 일 2', completed: true },
  ];

  it('renders todos and calls onToggle', () => {
    const onToggle = vi.fn();
    const onDelete = vi.fn();
    render(<TodoList todos={todos} onToggle={onToggle} onDelete={onDelete} />);

    const firstTodo = screen.getByText('할 일 1');
    fireEvent.click(firstTodo);

    expect(onToggle).toHaveBeenCalledWith('1');
  });

  it('calls onDelete when delete button is clicked', () => {
    const onToggle = vi.fn();
    const onDelete = vi.fn();
    render(<TodoList todos={todos} onToggle={onToggle} onDelete={onDelete} />);

    const deleteButtons = screen.getAllByText('삭제');
    fireEvent.click(deleteButtons[0]);

    expect(onDelete).toHaveBeenCalledWith('1');
  });

  it('shows empty message when no todos', () => {
    render(<TodoList todos={[]} onToggle={() => {}} onDelete={() => {}} />);
    expect(screen.getByText('할 일이 없습니다.')).toBeInTheDocument();
  });
});
