import { render, screen, fireEvent } from '@testing-library/react';
import TodoInput from '../components/TodoInput';
import { describe, it, expect, vi, beforeEach } from 'vitest';

describe('TodoInput', () => {
  let addTodo: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    addTodo = vi.fn();
    window.alert = vi.fn(); // alert mock
  });

  it('calls addTodo on submit', () => {
    render(<TodoInput addTodo={addTodo} />);
    const input = screen.getByRole('textbox');
    const button = screen.getByText('추가');

    fireEvent.change(input, { target: { value: '테스트 입력' } });
    fireEvent.click(button);

    expect(addTodo).toHaveBeenCalledWith('테스트 입력');
  });

  it('does not submit empty input', () => {
    render(<TodoInput addTodo={addTodo} />);
    const button = screen.getByText('추가');

    fireEvent.click(button);

    expect(addTodo).not.toHaveBeenCalled();
    expect(window.alert).toHaveBeenCalledWith('할 일을 입력해주세요.');
  });
});
