import { describe, it, expect } from 'vitest';
import { reducer, initialState } from '../hooks/reducer';
import type { Todo } from '../types/todo';

describe('reducer', () => {
  it('should add a todo', () => {
    const newState = reducer(initialState, {
      type: 'ADD_TODO',
      payload: '할 일',
    });

    expect(newState.todos.length).toBe(1);
    expect(newState.todos[0].text).toBe('할 일');
  });

  it('should toggle a todo', () => {
    const state = {
      ...initialState,
      todos: [{ id: '1', text: '일', completed: false }],
    };

    const newState = reducer(state, {
      type: 'TOGGLE_TODO',
      payload: '1',
    });

    expect(newState.todos[0].completed).toBe(true);
  });

  it('should delete a todo', () => {
    const state = {
      ...initialState,
      todos: [{ id: '1', text: '일', completed: false }],
    };

    const newState = reducer(state, {
      type: 'DELETE_TODO',
      payload: '1',
    });

    expect(newState.todos.length).toBe(0);
  });

  it('should set filter', () => {
    const newState = reducer(initialState, {
      type: 'SET_FILTER',
      payload: 'COMPLETED',
    });

    expect(newState.filter).toBe('COMPLETED');
  });

  it('should load todos', () => {
    const mockTodos: Todo[] = [
      { id: 'a', text: '1', completed: false },
      { id: 'b', text: '2', completed: true },
    ];

    const newState = reducer(initialState, {
      type: 'INIT_TODO',
      payload: mockTodos,
    });

    expect(newState.todos.length).toBe(2);
    expect(newState.todos[0].text).toBe('1');
    expect(newState.todos[1].text).toBe('2');
  });

  it('should clear completed todos', () => {
    const state = {
      ...initialState,
      todos: [
        { id: '1', text: '완료됨', completed: true },
        { id: '2', text: '미완료', completed: false },
      ],
    };

    const newState = reducer(state, { type: 'CLEAR_COMPLETED' });

    expect(newState.todos.length).toBe(1);
    expect(newState.todos[0].text).toBe('미완료');
  });
});
