import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import App from '../App';

describe('App', () => {
  beforeEach(() => {
    localStorage.clear(); // 테스트 간 데이터 충돌 방지
  });

  it('renders the title', () => {
    render(<App />);
    expect(screen.getByText('Todo App')).toBeInTheDocument();
  });

  it('adds a new todo item', () => {
    render(<App />);
    const input = screen.getByPlaceholderText('할 일을 입력하세요');
    const button = screen.getByText('추가');

    fireEvent.change(input, { target: { value: '공부하기' } });
    fireEvent.click(button);

    expect(screen.getByText('공부하기')).toBeInTheDocument();
  });

  it('toggles a todo item', () => {
    render(<App />);
    const input = screen.getByPlaceholderText('할 일을 입력하세요');
    const button = screen.getByText('추가');

    fireEvent.change(input, { target: { value: '할 일' } });
    fireEvent.click(button);

    const todo = screen.getByText('할 일');
    fireEvent.click(todo);

    expect(todo).toHaveClass('line-through');
  });

  it('deletes a todo item', () => {
    render(<App />);
    const input = screen.getByPlaceholderText('할 일을 입력하세요');
    const button = screen.getByText('추가');

    fireEvent.change(input, { target: { value: '삭제할 일' } });
    fireEvent.click(button);

    const deleteButton = screen.getByText('삭제');
    fireEvent.click(deleteButton);

    expect(screen.queryByText('삭제할 일')).not.toBeInTheDocument();
  });

  it('filters completed todos', () => {
    render(<App />);
    const input = screen.getByPlaceholderText('할 일을 입력하세요');
    const addButton = screen.getByText('추가');

    // 첫 번째 할 일 추가 후 완료 처리
    fireEvent.change(input, { target: { value: '완료 테스트' } });
    fireEvent.click(addButton);
    fireEvent.click(screen.getByText('완료 테스트')); // toggle

    // 필터를 '완료'로 전환
    fireEvent.click(screen.getByText('완료'));

    expect(screen.getByText('완료 테스트')).toBeInTheDocument();

    // 필터를 '미완료'로 전환
    fireEvent.click(screen.getByText('미완료'));

    expect(screen.queryByText('완료 테스트')).not.toBeInTheDocument();
  });

  it('init todos from localStorage on mount', () => {
    const mockTodos = [
      { id: '123', text: '저장된 일', completed: false },
    ];
    localStorage.setItem('todos', JSON.stringify(mockTodos));

    render(<App />);

    expect(screen.getByText('저장된 일')).toBeInTheDocument();
  });

  
});
