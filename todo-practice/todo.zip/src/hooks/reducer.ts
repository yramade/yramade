import { v4 as uuidv4 } from 'uuid';
import type { Action, State } from '../types/todo';

export const initialState: State = {
  todos: [],
  filter: 'ALL',
};

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case 'INIT_TODO':
    return {
      ...state,
      todos: action.payload,  // ✅ 배열 전체로 교체
    };
    case 'ADD_TODO': {
      const newTodo = {
        id: uuidv4(),
        text: action.payload.text,
        completed: false,
        dueDate: action.payload.dueDate,
        priority: action.payload.priority,
      };
      return {
        ...state,
        todos: [...state.todos, newTodo]
      };
    }

    case 'DELETE_TODO':
      return {
        ...state,
        todos: state.todos.filter((todo) => todo.id !== action.payload),
      };

    case 'TOGGLE_TODO':
      return {
        ...state,
        todos: state.todos.map((todo) =>
          todo.id === action.payload
            ? { ...todo, completed: !todo.completed }
            : todo
        ),
      };

    case 'SET_FILTER':
      return {
        ...state,
        filter: action.payload,
      };

    default:
      return state;
  }
};
