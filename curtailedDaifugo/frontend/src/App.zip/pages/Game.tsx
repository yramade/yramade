import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';

import { CardRankMap, MockCards, BotMockCards } from '../constants/game';

import ActionButtons from '../components/ActionButtons';
import MyCards from '../components/MyCards';
import SelectionArea from '../components/SelectionArea';
import TurnHistory from '../components/TurnHistory';
import RulePanel from '../components/RulesPanel';

export type Card = { id: string; label: string };
export type TurnRecordGroup = {
  turn: number;
  user?: Card | null;
  bot?: Card | null;
};

const TURN_TIMEOUT = 10; // 10초

export default function Game() {
  const [nickname, setNickname] = useState('');
  const navigate = useNavigate();
  const [turn, setTurn] = useState<'user' | 'bot'>('user');
  const [myCards, setMyCards] = useState(MockCards);
  const [botCards, setBotCards] = useState(BotMockCards);
  const [playedUserCards, setPlayedUserCards] = useState<Card[]>([]);
  const [playedBotCard, setPlayedBotCard] = useState<Card | null>(null);
  const [selectedCards, setSelectedCards] = useState<string[]>([]);
  const [isBotThinking, setIsBotThinking] = useState(false);
  const [turnHistory, setTurnHistory] = useState<TurnRecordGroup[]>([]);
  const [turnCount, setTurnCount] = useState(1);
  const [showRules, setShowRules] = useState(false);
  const [message, setMessage] = useState('');
  const [canEndTurn, setCanEndTurn] = useState(false);
  const [timer, setTimer] = useState(TURN_TIMEOUT);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const hasValidMove = (): boolean => {
    if (!playedBotCard) return true; // 첫 턴에는 낼 수 있음
    return myCards.some(card => getCardValue(card.id) > getCardValue(playedBotCard.id));
  };

  const handleEndTurn = () => {
    setMessage('');

    if (turn === 'user') {
      setTurn('bot');
    }
  };

  const resetTurnState = () => {
    // 봇 턴 끝난 후에 상태 초기화
    setPlayedBotCard(null);
    setCanEndTurn(false);
  };

  const toggleSelectCard = (cardId: string) => {
    // 이미 선택된 카드가 있을 때, 새 카드만 남기고 나머지 해제
    setSelectedCards(prev => {
      if (prev.length > 0 && !prev.includes(cardId)) {
        return [cardId];
      }
      return prev.includes(cardId) ? [] : [cardId];
    });
  };

  const handlePlayCards = () => {
    if (selectedCards.length === 0) {
      setMessage('카드를 선택하세요!');
      return;
    }

    if (selectedCards.length !== 1) {
      setMessage('카드는 한 장만 낼 수 있습니다.');
      return;
    }

    const selectedCardObj = myCards.find(card => card.id === selectedCards[0]);
    if (!selectedCardObj) return;

    if (!isValidPlay(selectedCardObj)) {
      setMessage('이 카드는 낼 수 없습니다. 더 높은 카드를 선택하세요.');
      return;
    }

    const remainingCards = myCards.filter(card => !selectedCards.includes(card.id));
    const playedCards = myCards.filter(card => selectedCards.includes(card.id));
    setMyCards(remainingCards);
    setPlayedUserCards([selectedCardObj]);
    setSelectedCards([]);
    setCanEndTurn(true);
    setTurnHistory(prev => {
      const existing = prev.find(t => t.turn === turnCount);
      if (existing) {
        return prev.map(t => (t.turn === turnCount ? { ...t, user: selectedCardObj } : t));
      } else {
        return [...prev, { turn: turnCount, user: selectedCardObj }];
      }
    });

    if (remainingCards.length === 0) {
      setMessage('');
      checkWinCondition();
      return;
    }

    checkWinCondition();
    console.log('낸 카드: ', playedCards[playedCards.length - 1].label);

    // 갱신된 카드(remainingCards)를 기준으로 validMove 판단
    const allCards = [...remainingCards, ...playedCards];
    const hasLargerCard = allCards.some(card => isValidPlay(card));
    if (!hasLargerCard) {
      console.log('allCards: ', allCards);
      console.log('hasLargerCard: ', hasLargerCard);
      setMessage('낼 수 있는 카드가 없어서 자동으로 턴을 넘깁니다.');
    } else {
      setMessage(''); // 아직 메세지가 남을 경우에 초기화
    }
  };

  const runBotTurn = () => {
    console.log('컴퓨터의 턴입니다!');
    setIsBotThinking(true);

    setTimeout(() => {
      if (botCards.length === 0) {
        setIsBotThinking(false);
        checkWinCondition();
        return;
      }

      let validCards: Card[] = [];
      // 반드시 유저가 방금 낸 카드 기준!
      const lastUserCardId = playedUserCards.length > 0 ? playedUserCards[playedUserCards.length - 1].id : undefined;

      if (!lastUserCardId) {
        validCards = botCards; // 첫 턴에는 아무 카드나 낼 수 있음
      } else {
        validCards = botCards.filter(card => getCardValue(card.id) > getCardValue(lastUserCardId));
      }

      // 이하 기존 코드 동일
      if (validCards.length === 0) {
        setIsBotThinking(false);
        setMessage('컴퓨터가 낼 수 있는 카드가 없어 턴을 넘깁니다.');
        setPlayedBotCard(null);
        setTurnHistory(prev => {
          const existing = prev.find(t => t.turn === turnCount);
          if (existing) {
            return prev.map(t => (t.turn === turnCount ? { ...t, bot: null } : t));
          } else {
            return [...prev, { turn: turnCount, bot: null }];
          }
        });
        setTurnCount(prev => prev + 1);
        checkWinCondition();
        return;
      }

      const randomIndex = Math.floor(Math.random() * validCards.length);
      const selectedCard = validCards[randomIndex];

      const remaining = botCards.filter(card => card.id !== selectedCard.id);
      setBotCards(remaining);
      setPlayedBotCard(selectedCard);
      setTurnHistory(prev => {
        const existing = prev.find(t => t.turn === turnCount);
        if (existing) {
          return prev.map(t => (t.turn === turnCount ? { ...t, bot: selectedCard } : t));
        } else {
          return [...prev, { turn: turnCount, bot: selectedCard }];
        }
      });
      setTurnCount(prev => prev + 1);
      setIsBotThinking(false);

      if (remaining.length === 0) {
        checkWinCondition();
        return;
      }

      checkWinCondition();
    }, 1000);
  };

  const endGame = (result: 'win' | 'lose' | 'draw') => {
    navigate('/result', {
      state: { result: result, turnHistory },
    });
  };

  const checkWinCondition = () => {
    if (myCards.length === 0 && botCards.length === 0) {
      setMessage('무승부입니다!');
      endGame('draw');
    } else if (myCards.length === 0) {
      setMessage(`🎉 ${nickname} 님이 이겼습니다! 축하드립니다!`);
      endGame('win');
    } else if (botCards.length === 0) {
      setMessage('😢 컴퓨터가 이겼습니다. 다음엔 꼭 이겨봐요!');
      endGame('lose');
    }
  };

  const getCardValue = (cardId: string) => {
    const value = cardId.replace(/[^0-9JQKA]/g, ''); // 'A♥' → 'A', '10♠' → '10'
    const rank = CardRankMap.get(value);

    if (rank === undefined) {
      console.error('잘못된 카드 값:', cardId);
      return -1;
    }
    return rank;
  };

  const isValidPlay = (card: Card): boolean => {
    if (turn === 'user') {
      // 유저 턴: 반드시 컴퓨터가 방금 낸 카드보다 커야 함
      if (!playedBotCard) return true;
      return getCardValue(card.id) > getCardValue(playedBotCard.id);
    } else {
      // 컴퓨터 턴: 반드시 유저가 방금 낸 카드보다 커야 함
      if (!playedBotCard && playedUserCards.length === 0) return true; // 첫 턴
      const lastPlayed = playedBotCard?.id || playedUserCards[playedUserCards.length - 1]?.id;

      if (!lastPlayed) return true;
      return getCardValue(card.id) > getCardValue(lastPlayed);
    }
  };

  useEffect(() => {
    const storedName = localStorage.getItem('nickname');
    if (!storedName) {
      navigate('/');
    } else if (storedName === nickname) {
      return;
    } else {
      setNickname(storedName);
    }
  }, [navigate, nickname]);

  useEffect(() => {
    if (turn === 'user') {
      const canPlay = hasValidMove();
      if (!canPlay) {
        setMessage('낼 수 있는 카드가 없습니다. 턴을 넘기세요.');
        setCanEndTurn(true); // 턴 넘기기만 허용
      }
    }
  }, [turn, myCards, playedBotCard]);

  useEffect(() => {
    if (turn === 'bot' && playedUserCards.length > 0) {
      runBotTurn();
      setTurn('user');
      resetTurnState();
    }
  }, [turn, playedUserCards]);

  /* useEffect(() => {
    if (turn === 'user' && myCards.length > 0 && hasValidMove()) {
      setTimer(TURN_TIMEOUT);

      if (timerRef.current) clearInterval(timerRef.current);

      timerRef.current = setInterval(() => {
        setTimer(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current!);
            setMessage('시간 초과로 턴이 자동으로 넘어갑니다.');
            handleEndTurn();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      setTimer(TURN_TIMEOUT);
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [turn, myCards, playedBotCard]); */

  if (!nickname) return null; // 또는 <LoadingSpinner />

  return (
    <div className="flex min-h-screen flex-col items-center bg-green-100 p-8">
      <h2 className="mb-4 text-2xl font-bold">
        {turn === 'user' ? `${nickname} 님의 턴입니다.` : '컴퓨터의 턴입니다.'}
      </h2>

      {/* 타이머 UI */}
      {turn === 'user' && hasValidMove() && (
        <div className="mb-2 text-lg font-semibold text-blue-700">남은 시간: {timer}초</div>
      )}

      <button
        onClick={() => setShowRules(prev => !prev)}
        className="mb-4 rounded bg-yellow-400 px-3 py-1 text-sm text-white hover:bg-yellow-500">
        {showRules ? '룰 숨기기' : '룰 보기'}
      </button>

      {showRules && <RulePanel />}
      {isBotThinking && <p className="mt-4 text-gray-600">컴퓨터가 카드를 고르는 중...</p>}
      <MyCards
        cards={myCards}
        selected={selectedCards}
        onToggle={toggleSelectCard}
      />
      <SelectionArea selected={selectedCards} />
      <ActionButtons
        disablePlay={turn !== 'user'}
        disableEndTurn={turn !== 'user' || !canEndTurn}
        onEndTurn={handleEndTurn}
        onPlay={handlePlayCards}
      />

      {message && <div className="mb-4 rounded bg-red-100 px-4 py-2 text-sm text-red-700 shadow">{message}</div>}

      {playedUserCards.length > 0 && (
        <div className="mt-4">
          <h3 className="font-semibold">당신이 낸 카드</h3>
          <div className="flex gap-2">
            {playedUserCards.map(card => (
              <div
                key={card.id}
                className="rounded border bg-white px-2 py-1 shadow">
                {card.label}
              </div>
            ))}
          </div>
        </div>
      )}

      {playedBotCard && (
        <div className="mt-4">
          <h3 className="font-semibold">컴퓨터가 낸 카드</h3>
          <div className="flex gap-2">
            <div className="rounded border bg-white px-2 py-1 shadow">{playedBotCard.label}</div>
          </div>
        </div>
      )}

      {turnHistory.length > 0 && <TurnHistory groupedHistory={turnHistory} />}
    </div>
  );
}
